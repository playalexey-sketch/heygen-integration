"""ПРОЦЕСС 1: Telegram-бот.

Polling Telegram + проигрывание этапов клиенту после /start.
Настройки читает из bot_data/stages.json (общий файл с веб-админкой),
перед отправкой каждому клиенту перечитывает файл заново — поэтому
изменения из админки действуют мгновенно, без перезапуска.

Запуск:  python bot.py
Лог:     bot_data/bot.log
"""
from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.exceptions import TelegramNetworkError

from app_common import apply_proxy, check_bot_online, load_proxy, setup
from config import Config
from handlers.admin import router as admin_router
from handlers.client import router as client_router
from handlers.manager import BOT_COMMANDS, router as manager_router, set_bot_menu

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger("bot")


async def poll_forever(bot: Bot, dp: Dispatcher, cfg: Config) -> None:
    """Polling с переподключением: обрыв сети не убивает бота.

    Перед каждым циклом перечитываем прокси — изменения из веб-панели
    (bot_data/proxy.txt) подхватываются без перезапуска, за ~15 секунд.
    """
    while True:
        try:
            apply_proxy(bot, load_proxy(cfg))
            # handle_signals=False: Ctrl+C обрабатывает run.bat (прерывает процесс).
            await dp.start_polling(bot, handle_signals=False)
            return  # polling остановлен штатно (shutdown)
        except TelegramNetworkError:
            log.error("Сеть недоступна — бот ЖИВ, переподключение через 15 секунд")
            await asyncio.sleep(15)


async def main() -> None:
    cfg = Config.from_env()
    storage, admin, sequencer, bot, content, crm = setup(cfg, log_name="bot.log")

    dp = Dispatcher(stages=storage, content=content, crm=crm, admin=admin, sequencer=sequencer, cfg=cfg)
    dp.include_router(admin_router)      # Telegram-команды /admin (этапы, тесты)
    dp.include_router(manager_router)    # правила/ссылки, медиа, прокси, CRM, рассылки
    dp.include_router(client_router)

    log.info("Бот запущен. Этапов: %d (включено: %d), медиа: %d, ключевых слов: %d, клиентов в CRM: %d. Файл: %s",
             len(storage.all()), len(storage.ordered()), len(content.all_media()),
             len(content.all_rules()), len(crm.all()), cfg.stages_path)
    if not cfg.admin_ids:
        log.warning("ADMIN_ID не задан: первым админом в Telegram станет тот, "
                    "кто пришлёт /admin. Веб-админка защищена паролем.")

    await check_bot_online(bot)
    try:
        await set_bot_menu(bot)
        log.info("Меню команд установлено (%d команд) — при вводе «/» появятся подсказки",
                 len(BOT_COMMANDS))
    except Exception:
        log.warning("Меню команд пока не установлено (нет связи) — обновите командой /setmenu")
    await poll_forever(bot, dp, cfg)


if __name__ == "__main__":
    Config.from_env()  # при ошибке — сразу понятное сообщение
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("Остановка бота")
    except SystemExit:
        raise
    except Exception:
        log.exception("Бот упал с ошибкой")
        print()
        print("!!! BOT CRASHED. Full details: bot_data\\bot.log")
        print()
        raise
